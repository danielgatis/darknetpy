from ..darknetpy import Detector
